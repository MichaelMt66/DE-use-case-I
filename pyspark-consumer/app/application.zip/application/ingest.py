import logging
import logging.config
import configparser
from os import path


class Ingest:

    def __init__(self, spark):
        self.spark = spark

    def read_from_kafka(self):
        config = configparser.ConfigParser()
#        log_file_path = path.join(path.dirname(path.dirname(path.abspath(__file__))), 'pipeline.ini')
#        logging.info(log_file_path)
        config.read('configs/config.ini')
        bootstrap_servers = config.get('KAFKA_CONFIGS', 'KAFKA_BROKERS')
        topic = config.get('KAFKA_CONFIGS', 'KAFKA_TOPIC')

        df_raw = self.spark \
            .readStream \
            .format("kafka") \
            .option("kafka.bootstrap.servers", bootstrap_servers) \
            .option("subscribe", topic) \
            .option("startingOffsets", "earliest") \
            .load()

        return df_raw